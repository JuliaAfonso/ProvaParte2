﻿using CartasDoPapaiNoel.Domain.Interfaces;
using Newtonsoft.Json;
using SiteCartinhasDoPapaiNoel.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using Formatting = Newtonsoft.Json.Formatting;

namespace CartasDoPapaiNoel.Data.Repositories
{
    public class CartaRepository : ICartaRepository
    {
        private List<Carta> _cartas;
        private readonly string _dataFilePath;

        public CartaRepository()
        {
            _dataFilePath = "cartas.json"; // Nome do arquivo JSON para persistência
            LoadData();
        }

        private void LoadData()
        {
            if (File.Exists(_dataFilePath))
            {
                var json = File.ReadAllText(_dataFilePath);
                _cartas = JsonConvert.DeserializeObject<List<Carta>>(json);
            }
            else
            {
                _cartas = new List<Carta>();
            }
        }

        public async Task<IEnumerable<Carta>> ObterTodasCartasAsync()
        {
            return await Task.FromResult(_cartas);
        }

        public async Task<Carta> ObterCartaPorIdAsync(object id)
        {
            return await Task.FromResult(_cartas.FirstOrDefault(c => c.Id == id));
        }

        public async Task AdicionarCartaAsync(Carta carta)
        {
            carta.Id = Guid.NewGuid();
            _cartas.Add(carta);
            await SaveDataAsync();
        }

        private async Task SaveDataAsync()
        {
            var json = JsonConvert.SerializeObject(_cartas, Formatting.Indented);
            await File.WriteAllTextAsync(_dataFilePath, json);
        }

        public void SeedData()
        {
            throw new NotImplementedException();
        }

        public Task<Carta> ObterCartaPorIdAsync(Guid id)
        {
            throw new NotImplementedException();
        }
    }
}
