﻿using CartasDoPapaiNoel.Application.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CartasDoPapaiNoel.Application.Interfaces
{
    public interface ICartaService
    {
        Task<IEnumerable<NovaCartaModel>> ObterTodasCartasAsync();
        Task<NovaCartaModel> ObterCartaPorIdAsync(Guid id);
        Task AdicionarCartaAsync(NovaCartaModel novaCarta);
    }
}
