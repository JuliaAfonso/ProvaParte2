﻿using AutoMapper;
using CartasDoPapaiNoel.Application.Interfaces;
using CartasDoPapaiNoel.Application.ViewModels;
using CartasDoPapaiNoel.Domain.Interfaces;
using SiteCartinhasDoPapaiNoel.Models;

namespace CartinhasDoPapaiNoel.Application.Services
{
    public class CartaService : ICartaService
    {
        private readonly ICartaRepository _cartaRepository;
        private readonly IMapper _mapper;

        public CartaService(ICartaRepository cartaRepository, IMapper mapper)
        {
            _cartaRepository = cartaRepository;
            _mapper = mapper;
        }

        public async Task<IEnumerable<CartaModel>> ObterTodasCartasAsync()
        {
            var cartas = await _cartaRepository.ObterTodasCartasAsync();
            return _mapper.Map<IEnumerable<CartaModel>>(cartas);

        }

        public async Task<NovaCartaModel> ObterCartaPorIdAsync(Guid id)
        {
            var carta = await _cartaRepository.ObterCartaPorIdAsync(id);
            if (carta == null)
                return null;

            return new NovaCartaModel
            {
                Id = carta.Id,
                NomeDaCrianca = carta.NomeDaCrianca,
                Endereco = new EnderecoModel
                {
                    Rua = carta.Endereco.Rua,
                    Numero = carta.Endereco.Numero,
                    Bairro = carta.Endereco.Bairro,
                    Cidade = carta.Endereco.Cidade,
                    Estado = carta.Endereco.Estado
                },
                Idade = carta.Idade,
                TextoDaCarta = carta.TextoDaCarta
            };
        }

        public async Task AdicionarCartaAsync(NovaCartaModel novaCarta)
        {
            var carta = new Carta
            {
                NomeDaCrianca = novaCarta.NomeDaCrianca,
                Endereco = new Endereco
                {
                    Rua = novaCarta.Endereco.Rua,
                    Numero = novaCarta.Endereco.Numero,
                    Bairro = novaCarta.Endereco.Bairro,
                    Cidade = novaCarta.Endereco.Cidade,
                    Estado = novaCarta.Endereco.Estado
                },
                Idade = novaCarta.Idade,
                TextoDaCarta = novaCarta.TextoDaCarta
            };

            await _cartaRepository.AdicionarCartaAsync(carta);
        }

        Task<IEnumerable<NovaCartaModel>> ICartaService.ObterTodasCartasAsync()
        {
            throw new NotImplementedException();
        }
    }
}