﻿using SiteCartinhasDoPapaiNoel.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CartasDoPapaiNoel.Domain.Interfaces
{
    public interface ICartaRepository
    {
        Task<IEnumerable<Carta>> ObterTodasCartasAsync();
        Task<Carta> ObterCartaPorIdAsync(Guid id);
        Task AdicionarCartaAsync(Carta carta);
        void SeedData();
    }
}
