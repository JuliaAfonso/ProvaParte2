﻿using CartasDoPapaiNoel.Application.AutoMapper;
using CartasDoPapaiNoel.Application.Interfaces;
using CartasDoPapaiNoel.Data.Repositories;
using CartasDoPapaiNoel.Domain.Interfaces;
using CartinhasDoPapaiNoel.Application.Services;

namespace CartinhasDoPapaiNoel.API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            //services.AddAutoMapper(typeof(CartaProfile));

            services.AddScoped<ICartaRepository, CartaRepository>();
            services.AddScoped<ICartaService, CartaService>();

            services.AddControllers();

        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
